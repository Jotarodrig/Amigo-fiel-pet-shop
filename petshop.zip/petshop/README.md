# 🐾 Amigo Fiel Pet Shop

# 🐾 PetShop Web App - Trabalho Final (AV2)

Aplicação web de um pet shop fictício, desenvolvida como **Trabalho Final de Front-end Frameworks (AV2)** do curso de Ciência da Computação[cite: 2, 3].

- **Tecnologias:** React 19 + TypeScript + Vite + React Router
- **Tema:** loja de produtos para cães e gatos, com catálogo, carrinho, login simulado, galeria de raças e formulário de contato.
- **APIs integradas (pontos extras):** [Dog CEO](https://dog.ceo/dog-api/), [The Cat API](https://thecatapi.com/) e [ViaCEP](https://viacep.com.br)[cite: 3].

> **Deploy (opcional):** _cole aqui o link da Vercel/Netlify, se publicarem._

---

## 👥 Integrantes e componentes desenvolvidos

Cada integrante é responsável por criar e explicar **2 componentes** (arquivos em `src/components/`)[cite: 2].

| Integrante | Componente 1 | Componente 2 |
|---|---|---|
| joao pedro | `Navbar` | `Footer` |
| jose wilson | `Hero` | `ProductCard` |
| Veras | `LoginForm` | `ContactForm` |
| Gustavo | `BreedCard` | `CartItem` |

Componentes de apoio do sistema: `CategoryFilter`, `SearchBar`, `Loading`, `ErrorMessage`, `DogDoDia` e `AddressFields`.
**Total: 14 componentes funcionais** (mínimo exigido: 8)[cite: 2].

---

## ✅ Requisitos do trabalho

| Requisito | Mínimo | Neste projeto |
|---|---|---|
| Componentes funcionais | 8 | **14** (`src/components/`)[cite: 2] |
| Páginas distintas | 5 | **6** + página 404 (`src/pages/`): Home, Produtos, Raças, Carrinho, Login, Contato[cite: 2] |
| Hooks diferentes | 4 | **6 nativos + 2 customizados** (tabela abaixo)[cite: 2] |
| TypeScript | obrigatório | 100% `.ts`/`.tsx`, com tipos em `src/types/`[cite: 2, 3] |
| Backend/API (extra) | opcional | **3 APIs reais** (Dog CEO, The Cat API, ViaCEP)[cite: 3] |

### Hooks utilizados

| Hook | Onde é usado | Para quê |
|---|---|---|
| `useState` | `Produtos`, `Navbar`, `LoginForm`, `ContactForm`… | Filtros, menu aberto, campos de formulário |
| `useEffect` | `useFetch`, `useLocalStorage`, `LoginForm` | Chamar APIs, salvar no localStorage, focar campo |
| `useContext` | `CartContext`, `AuthContext` (via `useCarrinho`/`useAuth`) | Compartilhar carrinho e usuário logado |
| `useRef` | `SearchBar`, `AddressFields`, `LoginForm` | Focar campos de forma imperativa |
| `useMemo` | `Produtos`, `Racas`, `CartContext` | Evitar recalcular filtros e totais |
| `useCallback` | `CartContext` | Manter estáveis as funções do contexto |
| `useFetch` _(custom)_ | `DogDoDia`, `Racas` | Controlar carregando/erro/dados de uma API |
| `useLocalStorage` _(custom)_ | `CartContext`, `AuthContext` | Persistir carrinho e login ao recarregar |

Também são usados `useNavigate` (React Router) em `LoginForm` e `Carrinho`.

---

## 🚀 Instalação e uso

**Pré-requisito:** [Node.js](https://nodejs.org) 20 ou superior.

```bash
# 1. Clonar o repositório
git clone <URL-DO-REPOSITORIO>
cd petshop

# 2. Instalar as dependências
npm install

# 3. (Opcional) Configurar a chave da The Cat API
cp .env.example .env
# edite o arquivo .env e preencha VITE_CAT_API_KEY

# 4. Rodar em modo de desenvolvimento
npm run dev